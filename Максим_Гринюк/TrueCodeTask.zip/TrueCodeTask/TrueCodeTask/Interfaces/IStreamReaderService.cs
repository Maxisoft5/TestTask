﻿namespace TrueCodeTask.Interfaces
{
    public interface IStreamReaderService
    {
        public string GetFileContent();
    }
}
